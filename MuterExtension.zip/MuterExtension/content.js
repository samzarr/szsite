const EXTENSION_WRAPPER_CLASS = "zoom-muter-button";
const EXTENSION_BUTTON_CLASS = "zoom-muter-button__control";
const PARTICIPANT_CARD_SELECTOR = ".video-avatar__avatar";
const PARTICIPANT_NAME_SELECTOR =
  ".video-avatar__avatar-footer span, .video-avatar__avatar-name";
const MUTED_BUTTON_CLASS = "zoom-muter-button__control--muted";
const ACTIVE_SPEAKER_BUTTON_CLASS = "zoom-muter-button__control--active-speaker";
const VIDEO_FRAME_SELECTOR = [
  ".gallery-video-container__video-frame",
  ".multi-speaker-main-container__video-frame",
  ".speaker-active-container__video-frame",
  ".speaker-bar-container__video-frame"
].join(", ");
const ACTIVE_SPEAKER_FRAME_SELECTORS = [
  ".gallery-video-container__video-frame--active",
  ".gallery-video-container__video-frame[class*='--active']",
  ".multi-speaker-main-container__video-frame--active",
  ".multi-speaker-main-container__video-frame[class*='--active']",
  ".speaker-active-container__video-frame",
  ".speaker-bar-container__video-frame--active",
  ".speaker-bar-container__video-frame[class*='--active']"
];
const MEETING_FRAME_PATH_PATTERN = /^\/wc\//;
const MUTATION_BATCH_DELAY_MS = 80;
const FRAME_STATE_HEARTBEAT_MS = 3000;
const STORAGE_KEY = "mutedParticipantsByName";

let mutationBatchTimerId = null;
let mutedParticipants = {};
let storageReadyPromise = null;
let trackedParticipantCards = new Set();
let activeSpeakerCard = null;
let activeSpeakerKey = null;
let frameStateHeartbeatId = null;

function shouldRunInThisFrame() {
  return MEETING_FRAME_PATH_PATTERN.test(window.location.pathname);
}

function normalizeParticipantName(name) {
  return name.trim().replace(/\s+/g, " ").toLowerCase();
}

function ensureStorageReady() {
  if (storageReadyPromise) {
    return storageReadyPromise;
  }

  storageReadyPromise = new Promise((resolve) => {
    if (!chrome?.storage?.local) {
      resolve();
      return;
    }

    chrome.storage.local.get([STORAGE_KEY], (result) => {
      mutedParticipants = result?.[STORAGE_KEY] ?? {};
      resolve();
    });
  });

  return storageReadyPromise;
}

function persistMutedParticipants() {
  if (!chrome?.storage?.local) {
    return;
  }

  chrome.storage.local.set({
    [STORAGE_KEY]: mutedParticipants
  });
}

function getParticipantName(card) {
  const nameNode = card.querySelector(PARTICIPANT_NAME_SELECTOR);
  return nameNode?.textContent.trim() || "participant";
}

function getParticipantKey(card) {
  return normalizeParticipantName(getParticipantName(card));
}

function isParticipantMuted(card) {
  return Boolean(mutedParticipants[getParticipantKey(card)]);
}

function getActiveSpeakerFrame(root = document) {
  for (const selector of ACTIVE_SPEAKER_FRAME_SELECTORS) {
    const activeFrame = root.querySelector(selector);
    if (activeFrame) {
      return activeFrame;
    }
  }

  return null;
}

function isParticipantSpeaking(card) {
  if (!activeSpeakerKey) {
    return false;
  }

  if (activeSpeakerCard === card) {
    return true;
  }

  return getParticipantKey(card) === activeSpeakerKey;
}

function setParticipantMuted(card, isMuted) {
  const participantKey = getParticipantKey(card);
  if (isMuted) {
    mutedParticipants[participantKey] = true;
  } else {
    delete mutedParticipants[participantKey];
  }

  persistMutedParticipants();
}

async function requestTabMuteState(isMuted) {
  if (!chrome?.runtime?.sendMessage) return;

  try {
    // The background script is set up to handle this as a promise.
    await chrome.runtime.sendMessage({
      type: "tabMuteIntent",
      isMuted,
    });
  } catch (error) {
    console.warn("[Zoom Muter] Could not send tab mute intent:", error.message);
    return;
  }
}

function updateButtonAppearance(button, participantName, isMuted, isSpeaking) {
  const isMutedAndSpeaking = isMuted && isSpeaking;
  button.textContent = isMutedAndSpeaking
    ? "MUTED!"
    : isMuted
      ? "Muted"
      : "Mute";
  button.classList.toggle(MUTED_BUTTON_CLASS, isMuted);
  button.classList.toggle(ACTIVE_SPEAKER_BUTTON_CLASS, isMutedAndSpeaking);
  button.setAttribute("aria-pressed", String(isMuted));
  button.setAttribute(
    "aria-label",
    `${isMuted ? "Unmute" : "Mute"} ${participantName} locally`
  );
  button.title = isMutedAndSpeaking
    ? `${participantName} is currently speaking and muted locally`
    : isMuted
      ? `Click to unmute ${participantName} locally`
      : `Click to mute ${participantName} locally`;
}

function syncButtonState(card) {
  const button = card.querySelector(`.${EXTENSION_BUTTON_CLASS}`);
  if (!button) {
    return;
  }

  updateButtonAppearance(
    button,
    getParticipantName(card),
    isParticipantMuted(card),
    isParticipantSpeaking(card)
  );
}

function syncButtonsForParticipantKey(participantKey) {
  if (!participantKey) {
    return;
  }

  trackedParticipantCards.forEach((card) => {
    if (!card.isConnected) {
      trackedParticipantCards.delete(card);
      return;
    }

    if (getParticipantKey(card) === participantKey) {
      syncButtonState(card);
    }
  });
}

async function syncTabMuteState() {
  await requestTabMuteState(Boolean(activeSpeakerKey && mutedParticipants[activeSpeakerKey]));
}

function createMuteButton(card) {
  const wrapper = document.createElement("div");
  wrapper.className = `video-avatar__mute-button ${EXTENSION_WRAPPER_CLASS}`;

  const button = document.createElement("button");
  button.type = "button";
  button.className =
    "ax-outline-blue avatar-more-xs-btn btn btn-primary btn-sm";
  button.classList.add(EXTENSION_BUTTON_CLASS);
  updateButtonAppearance(
    button,
    getParticipantName(card),
    isParticipantMuted(card),
    isParticipantSpeaking(card)
  );

  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();

    const nextMutedState = !isParticipantMuted(card);
    setParticipantMuted(card, nextMutedState);
    syncButtonState(card);
    void syncTabMuteState();
  });

  wrapper.appendChild(button);
  return wrapper;
}

function injectButton(card) {
  if (!(card instanceof HTMLElement)) {
    return;
  }

  if (card.querySelector(`.${EXTENSION_WRAPPER_CLASS}`)) {
    syncButtonState(card);
    return;
  }

  card.appendChild(createMuteButton(card));
}

function trackParticipantCard(card) {
  trackedParticipantCards.add(card);
  injectButton(card);
}

function untrackParticipantCard(card) {
  trackedParticipantCards.delete(card);

  if (activeSpeakerCard === card) {
    activeSpeakerCard = null;
  }
}

function forEachParticipantCard(root, callback) {
  if (!(root instanceof HTMLElement)) {
    return;
  }

  if (root.matches(PARTICIPANT_CARD_SELECTOR)) {
    callback(root);
  }

  root.querySelectorAll(PARTICIPANT_CARD_SELECTOR).forEach((card) => {
    callback(card);
  });
}

function scanForParticipantCards(root = document.body) {
  if (!root) {
    return;
  }

  forEachParticipantCard(root, trackParticipantCard);
}

function updateActiveSpeakerState() {
  const previousActiveSpeakerCard = activeSpeakerCard;
  const previousActiveSpeakerKey = activeSpeakerKey;
  const activeFrame = getActiveSpeakerFrame(document);
  const nextActiveSpeakerCard = activeFrame?.querySelector(PARTICIPANT_CARD_SELECTOR) ?? null;

  activeSpeakerCard = nextActiveSpeakerCard;
  activeSpeakerKey = nextActiveSpeakerCard ? getParticipantKey(nextActiveSpeakerCard) : null;

  if (previousActiveSpeakerCard && previousActiveSpeakerCard.isConnected) {
    syncButtonState(previousActiveSpeakerCard);
  }

  if (
    nextActiveSpeakerCard &&
    nextActiveSpeakerCard.isConnected &&
    nextActiveSpeakerCard !== previousActiveSpeakerCard
  ) {
    syncButtonState(nextActiveSpeakerCard);
  }

  if (previousActiveSpeakerKey !== activeSpeakerKey) {
    syncButtonsForParticipantKey(previousActiveSpeakerKey);
    syncButtonsForParticipantKey(activeSpeakerKey);
  }
}

async function flushMutationBatch() {
  mutationBatchTimerId = null;
  updateActiveSpeakerState();
  await syncTabMuteState();
}

function scheduleMutationBatch() {
  if (mutationBatchTimerId !== null) {
    window.clearTimeout(mutationBatchTimerId);
  }

  mutationBatchTimerId = window.setTimeout(flushMutationBatch, MUTATION_BATCH_DELAY_MS);
}

function handleMutations(mutations) {
  let shouldUpdateActiveSpeaker = false;

  for (const mutation of mutations) {
    if (
      mutation.type === "attributes" &&
      mutation.attributeName === "class" &&
      mutation.target instanceof HTMLElement
    ) {
      if (
        ACTIVE_SPEAKER_FRAME_SELECTORS.some((selector) =>
          mutation.target.matches?.(selector)
        ) ||
        mutation.target.matches?.(VIDEO_FRAME_SELECTOR) ||
        mutation.target.className.includes("video-frame")
      ) {
        shouldUpdateActiveSpeaker = true;
      }
    }

    for (const node of mutation.addedNodes) {
      if (!(node instanceof HTMLElement)) {
        continue;
      }

      forEachParticipantCard(node, trackParticipantCard);
      if (
        node.matches?.(VIDEO_FRAME_SELECTOR) ||
        node.querySelector?.(VIDEO_FRAME_SELECTOR)
      ) {
        shouldUpdateActiveSpeaker = true;
      }
    }

    for (const node of mutation.removedNodes) {
      if (!(node instanceof HTMLElement)) {
        continue;
      }

      forEachParticipantCard(node, untrackParticipantCard);
      shouldUpdateActiveSpeaker = true;
    }
  }

  if (shouldUpdateActiveSpeaker) {
    scheduleMutationBatch();
  }
}

function notifyFrameDetached() {
  if (!chrome?.runtime?.sendMessage) {
    return;
  }

  chrome.runtime.sendMessage({
    type: "frameDetached"
  });
}

function startFrameStateHeartbeat() {
  if (frameStateHeartbeatId !== null) {
    return;
  }

  frameStateHeartbeatId = window.setInterval(() => {
    void syncTabMuteState();
  }, FRAME_STATE_HEARTBEAT_MS);
}

function startObserver() {
  void ensureStorageReady().then(() => {
    scanForParticipantCards();
    updateActiveSpeakerState();
    return syncTabMuteState();
  });

  const observer = new MutationObserver(handleMutations);
  observer.observe(document.body, {
    attributes: true,
    attributeFilter: ["class"],
    childList: true,
    subtree: true
  });

  if (chrome?.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes[STORAGE_KEY]) {
        return;
      }

      mutedParticipants = changes[STORAGE_KEY].newValue ?? {};
      trackedParticipantCards.forEach((card) => {
        if (!card.isConnected) {
          trackedParticipantCards.delete(card);
          return;
        }

        syncButtonState(card);
      });
      void syncTabMuteState();
    });
  }

  window.addEventListener("resize", () => {
    scanForParticipantCards();
    scheduleMutationBatch();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      scanForParticipantCards();
      scheduleMutationBatch();
    }
  });
  window.addEventListener("pagehide", notifyFrameDetached, { once: true });
  startFrameStateHeartbeat();
}

if (shouldRunInThisFrame()) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startObserver, { once: true });
  } else {
    startObserver();
  }
}
