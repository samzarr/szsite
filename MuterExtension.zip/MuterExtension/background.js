const frameMuteStatesByTab = new Map();
const FRAME_STATE_TTL_MS = 10000;
let pruneTimerId = null;

function shouldHandleNavigation(details) {
  if (details.tabId < 0) {
    return false;
  }

  if (frameMuteStatesByTab.has(details.tabId)) {
    return true;
  }

  try {
    const url = new URL(details.url);
    return url.hostname === "app.zoom.us" || url.hostname.endsWith(".zoom.us");
  } catch {
    return false;
  }
}

function getFrameStates(tabId) {
  let frameStates = frameMuteStatesByTab.get(tabId);

  if (!frameStates) {
    frameStates = new Map();
    frameMuteStatesByTab.set(tabId, frameStates);
  }

  return frameStates;
}

function deleteFrameState(tabId, frameId) {
  const frameStates = frameMuteStatesByTab.get(tabId);
  if (!frameStates) {
    return;
  }

  frameStates.delete(frameId);

  if (frameStates.size === 0) {
    frameMuteStatesByTab.delete(tabId);
  }
}

function pruneExpiredFrameStates(tabId = null) {
  const now = Date.now();
  const tabEntries = tabId === null
    ? frameMuteStatesByTab.entries()
    : [[tabId, frameMuteStatesByTab.get(tabId)]];

  for (const [currentTabId, frameStates] of tabEntries) {
    if (!frameStates) {
      continue;
    }

    for (const [frameId, state] of frameStates.entries()) {
      if (!state?.updatedAt || now - state.updatedAt > FRAME_STATE_TTL_MS) {
        frameStates.delete(frameId);
      }
    }

    if (frameStates.size === 0) {
      frameMuteStatesByTab.delete(currentTabId);
    }
  }
}

function getNextFrameStateExpiry() {
  let nextExpiry = Infinity;

  for (const frameStates of frameMuteStatesByTab.values()) {
    for (const state of frameStates.values()) {
      if (state?.updatedAt) {
        nextExpiry = Math.min(nextExpiry, state.updatedAt + FRAME_STATE_TTL_MS);
      }
    }
  }

  return nextExpiry;
}

function schedulePruneTimer() {
  if (pruneTimerId !== null) {
    clearTimeout(pruneTimerId);
  }

  const nextExpiry = getNextFrameStateExpiry();
  if (!Number.isFinite(nextExpiry)) {
    pruneTimerId = null;
    return;
  }

  pruneTimerId = setTimeout(() => {
    pruneTimerId = null;
    const affectedTabIds = Array.from(frameMuteStatesByTab.keys());
    pruneExpiredFrameStates();

    for (const tabId of affectedTabIds) {
      void applyTabMute(tabId).catch((error) => {
        console.error("[Zoom Muter] Failed to update tab mute after stale frame prune:", error);
      });
    }

    schedulePruneTimer();
  }, Math.max(0, nextExpiry - Date.now()));
}

function shouldMuteTab(tabId) {
  pruneExpiredFrameStates(tabId);

  const frameStates = frameMuteStatesByTab.get(tabId);
  if (!frameStates) {
    return false;
  }

  for (const state of frameStates.values()) {
    if (state?.isMuted) {
      return true;
    }
  }

  return false;
}

async function applyTabMute(tabId) {
  const desiredMutedState = shouldMuteTab(tabId);
  const tab = await chrome.tabs.get(tabId);
  const currentlyMuted = Boolean(tab?.mutedInfo?.muted);
  const wasMutedByExtension = tab?.mutedInfo?.extensionId === chrome.runtime.id;

  if (desiredMutedState === currentlyMuted) {
    return desiredMutedState;
  }

  if (!desiredMutedState && !wasMutedByExtension) {
    return currentlyMuted;
  }

  await chrome.tabs.update(tabId, { muted: desiredMutedState });

  return desiredMutedState;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  const frameId = sender.frameId ?? 0;

  if (message?.type === "frameDetached") {
    if (typeof tabId !== "number") {
      return false;
    }

    deleteFrameState(tabId, frameId);
    schedulePruneTimer();
    void applyTabMute(tabId).catch((error) => {
      console.error("[Zoom Muter] Failed to update tab mute after frame detach:", error);
    });
    return false;
  }

  if (message?.type !== "tabMuteIntent") {
    return false;
  }

  if (typeof tabId !== "number") {
    sendResponse({
      ok: false,
      error: "Missing sender tab id"
    });
    return false;
  }

  const frameStates = getFrameStates(tabId);
  frameStates.set(frameId, {
    isMuted: Boolean(message.isMuted),
    updatedAt: Date.now()
  });
  schedulePruneTimer();

  void applyTabMute(tabId)
    .then((isMuted) => {
      sendResponse({
        ok: true,
        isMuted
      });
    })
    .catch((error) => {
      console.error("[Zoom Muter] Failed to update tab mute:", error);
      sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      });
    });

  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  frameMuteStatesByTab.delete(tabId);
  schedulePruneTimer();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== "loading") {
    return;
  }

  frameMuteStatesByTab.delete(tabId);
  schedulePruneTimer();
  void applyTabMute(tabId).catch((error) => {
    console.error("[Zoom Muter] Failed to update tab mute after tab loading:", error);
  });
});

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (!shouldHandleNavigation(details)) {
    return;
  }

  const { tabId, frameId } = details;

  if (frameId === 0) {
    frameMuteStatesByTab.delete(tabId);
  } else {
    deleteFrameState(tabId, frameId);
  }

  schedulePruneTimer();
  void applyTabMute(tabId).catch((error) => {
    console.error("[Zoom Muter] Failed to update tab mute after frame navigation:", error);
  });
});
